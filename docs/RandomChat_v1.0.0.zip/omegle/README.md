
# RandomChat

匿名随机聊天应用RandomChat使用方法

## 使用方法

```
基于nodejs和socket.io，在应用根目录下运行即可，http服务是3000端口，https是3011端口
$ npm install
$ node .
```

默认访问地址`https://localhost:3011`.由于安全机制限制，需要生成自己的Ca证书https://www.startssl.com/
## Features

- 基于webrtc技术，带宽占用低；
- 算法匹配用户随机聊天，默认一个房间只允许两个人加入
- 支持视频聊天和文字聊天
- 由于IE自身内核原因，不支持IE浏览器；其他浏览器都支持。

作者：whitebaby
邮箱：632244160@qq.com
移动端地址：http://shouji.baidu.com/software/9797753.html
版本v1.0.0 